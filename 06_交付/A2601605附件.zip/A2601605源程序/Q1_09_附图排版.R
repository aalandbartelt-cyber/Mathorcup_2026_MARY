#!/usr/bin/env Rscript
# Reuse frozen chart data; only unify supplementary legend typography.
suppressPackageStartupMessages({
  library(ggplot2);library(dplyr);library(patchwork);library(readr)
})
.mcup_args <- grep("^--file=", commandArgs(FALSE), value=TRUE)
.mcup_script <- if (length(.mcup_args)) sub("^--file=", "", .mcup_args[1]) else Sys.getenv("MCUP_R_SCRIPT")
.mcup_code <- dirname(normalizePath(.mcup_script, mustWork=TRUE))
.mcup_support <- dirname(.mcup_code)
.mcup_question <- "Q1"
source(file.path(.mcup_code, "绘图主题.R"))
.mcup_out <- file.path(.mcup_support, "绘图复算输出", "Q1_09_附图排版")
dir.create(.mcup_out, recursive=TRUE, showWarnings=FALSE)
OUT <- .mcup_out
dir.create(OUT,recursive=TRUE,showWarnings=FALSE)
FONT <- "SimSun"
legend_standard <- theme(
  text=element_text(family=FONT),
  legend.text=element_text(family=FONT,size=10.5,face="plain"))
export <- function(p,stem,w,h) {
  save_paper(p,file.path(OUT,paste0(stem,".png")),width=w,height=h,dpi=300)
  ggsave(file.path(OUT,paste0(stem,".pdf")),p,width=w,height=h,
         device=cairo_pdf,family=FONT,bg="white")
  ggsave(file.path(OUT,paste0(stem,".svg")),p,width=w,height=h,
         device=svglite::svglite,bg="white")
}

# Preserve every original panel, source table and canvas. Suppress the source
# writer rather than regenerating or replacing any existing chart file.
main_lines <- .mcup_read_lines("02_代码/Q1_感官评分/src/plot_q1_final.R",warn=FALSE)
begin <- grep("^save_png <- save_paper",main_lines)
end <- grep("^# 论文图文件内",main_lines)[1]
main_lines <- c(main_lines[seq_len(begin-1)],
                "save_paper <- function(...) invisible(NULL)",main_lines[end:length(main_lines)])
main_lines <- main_lines[seq_len(grep("^manifest <-",main_lines)-1)]
main_env <- new.env(parent=globalenv())
# The source consults this only for mkdir; no PNG/SVG/manifest writer is enabled.
Sys.setenv(Q1_FIGURE_DIR=OUT)
eval(parse(text=main_lines),envir=main_env)
supp1 <- main_env$p_s1_combined & legend_standard
export(supp1,"附图S1_残差诊断与量表映射",9.5,7.0)

validation_lines <- .mcup_read_lines("04_图表/Q1_感官评分/待审_20261027/plot_validation_drafts.R",warn=FALSE)
begin <- grep("^save_both <- function",validation_lines)
end <- grep("^rep <-",validation_lines)[1]
validation_lines <- c(validation_lines[seq_len(begin-1)],
                      "save_both <- function(...) invisible(NULL)",
                      validation_lines[end:length(validation_lines)])
validation_env <- new.env(parent=globalenv())
eval(parse(text=validation_lines),envir=validation_env)
supp2 <- validation_env$s2 & legend_standard
supp3 <- validation_env$s3 & legend_standard
export(supp2,"附图S2_消融与负对照",8.6,7.2)
export(supp3,"附图S3_逐目标预测可靠性",8.6,7.0)
capture.output(sessionInfo(),file=file.path(OUT,"R_session_info.txt"))
cat("Supplementary charts exported with SimSun 10.5pt legends.\n")
